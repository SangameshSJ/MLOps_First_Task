# chatbot/__init__.py
from .chatbot import chatbot